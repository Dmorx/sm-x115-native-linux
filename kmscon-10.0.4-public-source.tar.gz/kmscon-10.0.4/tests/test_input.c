/*
 * test_input - Test the input system - hotplug and keypresses
 *
 * Copyright (c) 2011 Ran Benita <ran234@gmail.com>
 * Copyright (c) 2012 David Herrmann <dh.herrmann@googlemail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

static void print_help();

#include <errno.h>
#include <linux/input.h>
#include <locale.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/signalfd.h>
#include <unistd.h>
#include <xkbcommon/xkbcommon.h>
#include "input/input.h"
#include "monitor.h"
#include "shl/eloop.h"
#include "shl/log.h"
#include "test_include.h"

static struct ev_eloop *eloop;
static struct input *input;

struct {
	char *xkb_model;
	char *xkb_layout;
	char *xkb_variant;
	char *xkb_options;
	char *locale;
	char *xkb_keymap;
	char *xkb_compose_file;
} input_conf;

/* Pressing Ctrl-\ should toggle the capturing. */
static void sig_quit(struct ev_eloop *p, struct signalfd_siginfo *info, void *data)
{
	if (!input)
		return;

	if (input_is_awake(input)) {
		input_sleep(input);
		log_info("Went to sleep\n");
	} else {
		input_wake_up(input);
		log_info("Woke Up\n");
	}
}

static void print_modifiers(unsigned int mods)
{
	if (mods & INPUT_SHIFT_MASK)
		printf("SHIFT ");
	if (mods & INPUT_LOCK_MASK)
		printf("LOCK ");
	if (mods & INPUT_CONTROL_MASK)
		printf("CONTROL ");
	if (mods & INPUT_ALT_MASK)
		printf("ALT ");
	if (mods & INPUT_LOGO_MASK)
		printf("LOGO ");
	printf("\n");
}

static void input_arrived(struct input *input, struct input_key_event *ev, void *data)
{
	char s[32];

	xkb_keysym_get_name(ev->keysyms[0], s, sizeof(s));
	printf("sym %s ", s);
	if (ev->codepoints[0] != INPUT_INVALID) {
		/*
		 * Just a proof-of-concept hack. This works because glibc uses
		 * UTF-32 (= UCS-4) as the internal wchar_t encoding.
		 */
		printf("unicode %lc ", ev->codepoints[0]);
	}
	print_modifiers(ev->mods);
}

static void setup_input(struct uterm_monitor *mon)
{
	int ret;

	ret = input_new(&input, eloop);
	if (ret)
		return;
	ret = input_set_keymap(input, input_conf.xkb_model, input_conf.xkb_layout,
			       input_conf.xkb_variant, input_conf.xkb_options,
			       input_conf.xkb_keymap);
	if (ret)
		return;

	input_set_compose(input, input_conf.locale, input_conf.xkb_compose_file);
	input_set_conf(input, 250, 50, true);
	ret = input_register_key_cb(input, input_arrived, NULL);
	if (ret)
		return;
	input_wake_up(input);
}

static void free_input(struct uterm_monitor *mon)
{
	input_unregister_key_cb(input, input_arrived, NULL);
	input_unref(input);
}

static void monitor_new_dev(const char *node, enum uterm_monitor_dev_type type,
			    enum uterm_monitor_dev_flag flags, void *data,
			    struct uterm_monitor_dev *udev)
{
	void *dev_data;

	if (type == UTERM_MONITOR_INPUT) {
		dev_data = input_add_dev(input, node);
		uterm_monitor_set_dev_data(udev, dev_data);
	}
}

static void monitor_free_dev(void *data, enum uterm_monitor_dev_type type, void *dev_data)
{
	if (type == UTERM_MONITOR_INPUT)
		input_remove_dev(input, dev_data);
}

static struct uterm_monitor_cb monitor_cb = {
	.new_dev = monitor_new_dev,
	.free_dev = monitor_free_dev,
};

static void print_help()
{
	/*
	 * Usage/Help information
	 * This should be scaled to a maximum of 80 characters per line:
	 *
	 * 80 char line:
	 *       |   10   |    20   |    30   |    40   |    50   |    60   |    70   |    80   |
	 *      "12345678901234567890123456789012345678901234567890123456789012345678901234567890\n"
	 * 80 char line starting with tab:
	 *       |10|    20   |    30   |    40   |    50   |    60   |    70   |    80   |
	 *      "\t901234567890123456789012345678901234567890123456789012345678901234567890\n"
	 */
	fprintf(stderr,
		"Usage:\n"
		"\t%1$s [options]\n"
		"\t%1$s -h [options]\n"
		"\n"
		"You can prefix boolean options with \"no-\" to negate it. If an argument is\n"
		"given multiple times, only the last argument matters if not otherwise stated.\n"
		"\n"
		"General Options:\n" TEST_HELP "\n"
		"Input Device Options:\n"
		"\t    --xkb-model <model>     [-]     Set XkbModel for input devices\n"
		"\t    --xkb-layout <layout>   [-]     Set XkbLayout for input devices\n"
		"\t    --xkb-variant <variant> [-]     Set XkbVariant for input devices\n"
		"\t    --xkb-options <options> [-]     Set XkbOptions for input devices\n"
		"\t    --locale <locale>       [-]     Set locale for input devices\n"
		"\t    --xkb-keymap <FILE>     [-]     Use a predefined keymap for\n"
		"\t                                    input devices\n",
		"test_input");
	/*
	 * 80 char line:
	 *       |   10   |    20   |    30   |    40   |    50   |    60   |    70   |    80   |
	 *      "12345678901234567890123456789012345678901234567890123456789012345678901234567890\n"
	 * 80 char line starting with tab:
	 *       |10|    20   |    30   |    40   |    50   |    60   |    70   |    80   |
	 *      "\t901234567890123456789012345678901234567890123456789012345678901234567890\n"
	 */
}

struct conf_option options[] = {
	TEST_OPTIONS,
	CONF_OPTION_STRING(0, "xkb-model", &input_conf.xkb_model, ""),
	CONF_OPTION_STRING(0, "xkb-layout", &input_conf.xkb_layout, ""),
	CONF_OPTION_STRING(0, "xkb-variant", &input_conf.xkb_variant, ""),
	CONF_OPTION_STRING(0, "xkb-options", &input_conf.xkb_options, ""),
	CONF_OPTION_STRING(0, "locale", &input_conf.locale, "C"),
	CONF_OPTION_STRING(0, "xkb-keymap", &input_conf.xkb_keymap, ""),
	CONF_OPTION_STRING(0, "xkb-compose-file", &input_conf.xkb_compose_file, ""),
};

int main(int argc, char **argv)
{
	int ret;
	struct uterm_monitor *mon;
	size_t onum;

	onum = sizeof(options) / sizeof(*options);
	ret = test_prepare(options, onum, argc, argv, &eloop);
	if (ret)
		goto err_fail;

	if (!setlocale(LC_ALL, "")) {
		log_err("Cannot set locale: %m");
		ret = -EFAULT;
		goto err_exit;
	}

	ret = uterm_monitor_new(&mon, eloop, &monitor_cb, NULL);
	if (ret)
		goto err_exit;

	ret = ev_eloop_register_signal_cb(eloop, SIGQUIT, sig_quit, NULL);
	if (ret)
		goto err_mon;

	setup_input(mon);

	ret = system("stty -echo");
	if (ret)
		goto err_signal;

	uterm_monitor_scan(mon, "seat0");
	ev_eloop_run(eloop, -1);

	ret = system("stty echo");
	if (ret)
		goto err_signal;

	free_input(mon);

err_signal:
	ev_eloop_unregister_signal_cb(eloop, SIGQUIT, sig_quit, NULL);
err_mon:
	uterm_monitor_unref(mon);
err_exit:
	test_exit(options, onum, eloop);
err_fail:
	if (ret != -ECANCELED)
		test_fail(ret);
	return abs(ret);
}
