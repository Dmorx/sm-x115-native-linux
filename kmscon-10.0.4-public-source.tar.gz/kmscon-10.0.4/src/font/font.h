/*
 * kmscon - Font Renderer
 *
 * Copyright (c) 2012-2013 David Herrmann <dh.herrmann@googlemail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * Font Renderer
 */

#ifndef KMSCON_FONT_H
#define KMSCON_FONT_H

#include <stdint.h>
#include <string.h>
#include "shl/module.h"
#include "video/video.h"

/* fonts */

struct kmscon_font_attr;
struct kmscon_glyph;
struct kmscon_font;
struct kmscon_font_ops;

#define KMSCON_FONT_MAX_NAME 128
#define KMSCON_FONT_DEFAULT_NAME "monospace"
#define KMSCON_FONT_DEFAULT_PPI 72

#define FONT_REPLACEMENT_CHAR 0x25a1
#define FONT_FULL_BLOCK 0x2588
#define FONT_VBAR 0x258e

struct kmscon_font_attr {
	bool bold;
	bool italic;
	bool underline;
};

struct kmscon_glyph {
	bool double_width;
	struct video_buffer buf; // Must be last
};

static inline unsigned int kmscon_glyph_cwidth(const struct kmscon_glyph *glyph)
{
	return glyph->double_width ? 2 : 1;
}

static inline uint64_t kmscon_glyph_id(uint32_t ch, uint8_t u8)
{
	return (uint64_t)ch | (uint64_t)u8 << 32;
}

struct kmscon_font {
	unsigned long ref;
	struct shl_register_record *record;
	const struct kmscon_font_ops *ops;
	unsigned int height;
	unsigned int width;
	unsigned increase_step;
	void *data;
};

struct kmscon_font_ops {
	const char *name;
	struct shl_module *owner;
	int (*init)(struct kmscon_font *out, const char *name, unsigned int height);
	void (*destroy)(struct kmscon_font *font);
	bool (*has_glyph)(struct kmscon_font *font, struct kmscon_font_attr *attr, uint32_t ch);
	struct kmscon_glyph *(*render)(struct kmscon_font *font, struct kmscon_font_attr *attr,
				       uint32_t ch);
};

int kmscon_font_register(const struct kmscon_font_ops *ops);
void kmscon_font_unregister(const char *name);

int kmscon_font_find(struct kmscon_font **out, const char *name, unsigned int height,
		     const char *backend);
void kmscon_font_ref(struct kmscon_font *font);
void kmscon_font_unref(struct kmscon_font *font);

struct kmscon_glyph *kmscon_font_render(struct kmscon_font *font, struct kmscon_font_attr *attr,
					uint32_t ch);
bool kmscon_font_has_glyph(struct kmscon_font *font, struct kmscon_font_attr *attr, uint32_t ch);

/* modularized backends */

extern struct kmscon_font_ops kmscon_font_8x16_ops;
extern struct kmscon_font_ops kmscon_font_psf_ops;
extern struct kmscon_font_ops kmscon_font_unifont_ops;
extern struct kmscon_font_ops kmscon_font_pango_ops;
extern struct kmscon_font_ops kmscon_font_freetype_ops;

#endif /* KMSCON_FONT_H */
