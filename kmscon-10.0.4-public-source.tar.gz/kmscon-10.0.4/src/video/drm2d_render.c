/*
 * Kmscon - DRM2D Video backend
 *
 * Copyright (c) 2011-2013 David Herrmann <dh.herrmann@googlemail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * DRM2D Video backend rendering functions
 */

#include <fcntl.h>
#include <inttypes.h>
#include <shl/misc.h>
#include <stdbool.h>
#include <sys/mman.h>
#include <unistd.h>
#include <xf86drm.h>
#include <xf86drmMode.h>
#include "drm2d_internal.h"
#include "video.h"
#include "video_internal.h"

#define LOG_SUBSYSTEM "drm2d_render"

int drm2d_display_blend(struct display *disp, const struct video_blend_req *req)
{
	unsigned int tmp;
	uint8_t *dst;
	const uint8_t *src;
	unsigned int width, height, i;
	unsigned int sw, sh;
	uint_fast32_t r, g, b, out;
	struct drm2d_rb *rb;
	struct drm2d_display *d2d = disp->data;

	if (!req || !req->buf)
		return -EINVAL;

	rb = &d2d->rb[d2d->current_rb ^ 1];
	sw = disp->width;
	sh = disp->height;

	width = min(req->w, req->buf->width);
	tmp = req->x + width;
	if (tmp < req->x || req->x >= sw)
		return -EINVAL;
	if (tmp > sw)
		width = sw - req->x;

	height = min(req->h, req->buf->height);
	tmp = req->y + height;
	if (tmp < req->y || req->y >= sh)
		return -EINVAL;
	if (tmp > sh)
		height = sh - req->y;

	dst = rb->map;
	dst = &dst[req->y * rb->stride + req->x * 4];
	src = req->buf->data;

	while (height--) {
		for (i = 0; i < width; ++i) {
			/* Division by 255 (t /= 255) is done with:
			 *   t += 0x80
			 *   t = (t + (t >> 8)) >> 8
			 * This speeds up the computation by ~20% as the
			 * division is not needed. */
			if (src[i] == 0) {
				r = req->br;
				g = req->bg;
				b = req->bb;
				out = (r << 16) | (g << 8) | b;
			} else if (src[i] == 255) {
				r = req->fr;
				g = req->fg;
				b = req->fb;
				out = (r << 16) | (g << 8) | b;
			} else {
				r = req->fr * src[i] + req->br * (255 - src[i]);
				r += 0x80;
				r = (r + (r >> 8)) >> 8;

				g = req->fg * src[i] + req->bg * (255 - src[i]);
				g += 0x80;
				g = (g + (g >> 8)) >> 8;

				b = req->fb * src[i] + req->bb * (255 - src[i]);
				b += 0x80;
				b = (b + (b >> 8)) >> 8;
				out = (r << 16) | (g << 8) | b;
			}

			((uint32_t *)dst)[i] = out;
		}
		dst += rb->stride;
		src += req->buf->width;
	}
	return 0;
}

int drm2d_display_clear(struct display *disp, uint8_t r, uint8_t g, uint8_t b)
{
	struct drm2d_rb *rb;
	struct drm2d_display *d2d = disp->data;
	unsigned int width = disp->width;
	unsigned int height = disp->height;
	uint8_t *dst;
	int i;

	rb = &d2d->rb[d2d->current_rb ^ 1];
	dst = rb->map;

	while (height--) {
		for (i = 0; i < width; ++i)
			((uint32_t *)dst)[i] = (r << 16) | (g << 8) | b;
		dst += rb->stride;
	}

	return 0;
}
