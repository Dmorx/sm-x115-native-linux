/*
 * Main App
 *
 * Copyright (c) 2012 David Herrmann <dh.herrmann@googlemail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * This includes global data for the whole kmscon application. For instance,
 * global parameters can be accessed via this header.
 */

#ifndef KMSCON_CONFIG_H
#define KMSCON_CONFIG_H

#include <libtsm.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "conf.h"
#include "shl/dlist.h"

enum kmscon_conf_gpu_selection {
	KMSCON_GPU_ALL,
	KMSCON_GPU_AUX,
	KMSCON_GPU_PRIMARY,
};

typedef uint8_t palette_t[TSM_COLOR_NUM][3];

struct kmscon_conf_t {
	/* header information */
	bool seat_config;

	/* General Options */
	/* show help/usage information */
	bool help;
	/* show version information */
	bool version;
	/* exit application after parsing options */
	bool exit;
	/* enable verbose info messages */
	bool verbose;
	/* enable debug messages */
	bool debug;
	/* disable notices and warnings */
	bool silent;
	/* config directory name */
	char *configdir;

	/* Seat Options */
	/* VT number to run on */
	char *vt;
	/* enter new VT directly */
	bool switchvt;
	/* use libseat */
	bool libseat;

	/* Session Options */
	/* sessions */
	unsigned int session_max;
	/* allow keyboard session control */
	bool session_control;

	/* Terminal Options */
	/* display /etc/issue before login prompt */
	bool issue;
	/* colon-separated issue search path */
	char *issue_path;
	/* asciicast animation to play after opening the terminal session */
	char *asciicast;
	/* loop asciicast animation */
	bool asciicast_loop;
	/* custom login process */
	bool login;
	/* argv for login process */
	char **argv;
	/* when the login process exits, exit kmscon */
	bool oneshot;
	/* TERM value */
	char *term;
	/* reset environment */
	bool reset_env;
	/* Send delete when backspace is pressed */
	bool backspace_delete;
	/* terminal scroll-back buffer size */
	unsigned int sb_size;
	/* enable bell forwarding */
	bool bell;
	/* enable cursor and text blinking */
	bool blink;

	/* Input Options */
	/* input KBD model */
	char *xkb_model;
	/* input KBD layout */
	char *xkb_layout;
	/* input KBD variant */
	char *xkb_variant;
	/* input KBD options */
	char *xkb_options;
	/* input predefined KBD keymap */
	char *xkb_keymap;
	/* input predefined KBD compose file */
	char *xkb_compose_file;
	/* keyboard key-repeat delay */
	unsigned int xkb_repeat_delay;
	/* keyboard key-repeat rate */
	unsigned int xkb_repeat_rate;
	/* Enable mouse support */
	bool mouse;
	/* Natural scrolling (invert mouse wheel direction) */
	bool natural_scrolling;
	/* Force software cursor */
	bool soft_cursor;
	/* DPMS screen timeout in seconds (0 = disabled) */
	unsigned int dpms_timeout;

	/* Grabs / Keyboard-Shortcuts */
	/* scroll-up grab */
	struct conf_grab *grab_scroll_up;
	/* scroll-down grab */
	struct conf_grab *grab_scroll_down;
	/* page-up grab */
	struct conf_grab *grab_page_up;
	/* page-down grab */
	struct conf_grab *grab_page_down;
	/* zoom-in grab */
	struct conf_grab *grab_zoom_in;
	/* zoom-out grab */
	struct conf_grab *grab_zoom_out;
	/* session-next grab */
	struct conf_grab *grab_session_next;
	/* session-prev grab */
	struct conf_grab *grab_session_prev;
	/* session-close grab */
	struct conf_grab *grab_session_close;
	/* terminal-new grab */
	struct conf_grab *grab_terminal_new;
	/* rotate output clock-wise grab */
	struct conf_grab *grab_rotate_cw;
	/* rotate output counter-clock-wise grab */
	struct conf_grab *grab_rotate_ccw;
	/* reboot system grab */
	struct conf_grab *grab_reboot;

	/* Video Options */
	/* use DRM if available */
	bool drm;
	/* use 3D hardware-acceleration if available */
	bool hwaccel;
	/* gpu selection mode */
	unsigned int gpus;
	/* use current KMS video mode to avoid modesetting */
	bool use_original_mode;
	/* screen resolution */
	char *mode;
	/* multiple monitors */
	char *multi_monitor;
	/* orientation/rotation of output */
	char *rotate;

	/* Font Options */
	/* font engine */
	char *font_engine;
	/* font size */
	unsigned int font_size;
	/* font name */
	char *font_name;

	/* Palette Options */
	/* color palette */
	char *palette;
	/* custom palette */
	palette_t custom_palette;
};

int kmscon_conf_new(struct conf_ctx **out);
void kmscon_conf_free(struct conf_ctx *ctx);
int kmscon_conf_load_main(struct conf_ctx *ctx, int argc, char **argv);
int kmscon_conf_load_seat(struct conf_ctx *ctx, const struct conf_ctx *main, const char *seat);

#endif /* KMSCON_CONFIG_H */
